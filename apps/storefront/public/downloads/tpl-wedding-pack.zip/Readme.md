# South Indian Wedding Film Pack
Created by Venkatesh Narasimha

A premium template pack for traditional and modern South Indian wedding edits, featuring timing sheets, transitions, and audio sync guidelines.

## Contents:
1. `South_Indian_Wedding_Template.prproj` - Premiere Pro sequence template.
2. `Transition_Presets/South_Indian_Glow.prfpset` - Light leaks transition preset.
3. `Carnatic_Beats_Cue_Sheet.txt` - Timing indicators for traditional Carnatic percussion edits (Nadaswaram & Thavil timing).

## How to use:
1. Import `South_Indian_Wedding_Template.prproj` into Premiere.
2. Use the timeline layout to align your footage according to the ceremony stages marked on the track (Kashi Yatra, Mangalya Dharanam, Saptapadi).
3. Import the `.prfpset` file in your Effects panel under Presets to apply custom wedding glow transitions.
