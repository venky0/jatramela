# Temple Particle Pack - After Effects Compositions
Created by Venkatesh Narasimha

A library of 60 pre-built particle composition templates (incense smoke, golden temple dust, diya light flares, rangoli sparks) to add cultural depth and beauty to your visual assets.

## Inside the Pack:
1. `Temple_Particle_Pack.aep` - After Effects project containing nested comps:
   - *Incense Smoke (Slow)*
   - *Incense Smoke (Dense)*
   - *Golden Temple Dust (Slow Drift)*
   - *Rangoli Sparkle Overlay (Radial)*
   - *Deepavali Diya Spark & Flare*
2. `Assets/` - Pre-rendered alpha-channel particles for drag-and-drop.

## How to use:
1. Open your own After Effects project.
2. Go to **File -> Import -> File...** and select `Temple_Particle_Pack.aep`.
3. Choose to import the entire project or select individual compositions.
4. Drag the comps over your background layers and set blending mode to **Add** or **Screen**.
