# Karnataka Reel Template Pack
Created by Venkatesh Narasimha

10 fully-customisable After Effects vertical (9:16) reel templates optimized for sharing Karnataka's heritage and landscapes.

## Package Contents:
1. `Karnataka_Reels_Template.aep` - After Effects project containing:
   - *Template 01: Hampi Stone Chariot (Cinematic Text Reveal)*
   - *Template 02: Coorg Mountains (Misty Parallax Transition)*
   - *Template 03: Jog Falls (Dynamic Kinetic Cut)*
   - *Template 04: Mysore Palace (Festive Glow Grid)*
   - *Template 05: Gokarna Surf (Modern Split Screen)*
2. `Fonts/` - Font styling parameters.
3. `Guide.txt` - Step-by-step export setup for Instagram and YouTube shorts.

## How to use:
1. Open the project in After Effects.
2. In the Project Panel, open the `Reels Comps` folder.
3. Double-click any template composition.
4. Replace placeholder image/video assets with your own footage.
5. Edit text layers to customize titles.
6. Export as H.264 MP4.
