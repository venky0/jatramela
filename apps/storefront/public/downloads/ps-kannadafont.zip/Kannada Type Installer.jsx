/**
 * Kannada Type Installer v1.0
 * by Venkatesh Narasimha
 */
(function() {
    if (app.documents.length === 0) {
        var doc = app.documents.add(1920, 1080, 72, "Kannada Typography Canvas");
    } else {
        var doc = app.activeDocument;
    }
    
    var originalRuler = app.preferences.rulerUnits;
    app.preferences.rulerUnits = Units.PIXELS;

    var titleLayer = doc.artLayers.add();
    titleLayer.kind = LayerKind.TEXT;
    titleLayer.name = "Kannada Title - Bold";
    
    var txtItem = titleLayer.textItem;
    txtItem.contents = "ಜಾತ್ರಾಮೇಳ - ಕನ್ನಡ";
    txtItem.size = 110;
    try {
        txtItem.font = "BalooTamma2-Bold";
    } catch(e) {
        try {
            txtItem.font = "NotoSansKannada-Bold";
        } catch(e2) {}
    }
    
    // Set position
    txtItem.position = [150, 400];
    
    app.preferences.rulerUnits = originalRuler;
    alert("Kannada Typography canvas layer created! Ensure Baloo Tamma 2 font is installed.");
})();
