# Karnataka Colour Grader LUTs & Script
Created by Venkatesh Narasimha

This package includes a LUT-based colour grading script and three custom Look-Up Tables (LUTs) in `.cube` format, inspired by the beautiful landscapes of Karnataka.

## Package Contents:
1. `Karnataka Color Grader.jsx` - After Effects script to apply the grading LUTs.
2. `LUTs/Mysuru_Golden_Hour.cube` - Warm golden hues of the Palace City.
3. `LUTs/Coorg_Emerald.cube` - Lush deep green tones of the Western Ghats.
4. `LUTs/Hampi_Ochre_Ruins.cube` - Cinematic warm, earthy tones of historical ruins.

## Installation & How to Use:
1. Copy the `.cube` files from the `LUTs` directory into your After Effects LUT folder (usually `C:\Program Files\Adobe\Adobe After Effects <version>\Support Files\Presets\OCIO\LUTs` or run manually via Lumetri Color effect).
2. Open After Effects, go to **File -> Scripts -> Run Script File...** and select `Karnataka Color Grader.jsx`.
3. Choose the grading LUT from the dropdown list and click **Apply Color Grade** to add an adjustment layer with the LUT pre-applied.
