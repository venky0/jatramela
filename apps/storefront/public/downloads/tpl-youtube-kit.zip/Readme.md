# YouTube Channel Kit
Created by Venkatesh Narasimha

A comprehensive bundle containing thumbnail PSD templates, lower thirds Premiere Pro projects, and audio mark templates.

## Contents:
1. `Thumbnails/Clean_Vlog_Thumbnail.psd` - Click-optimized thumbnail template.
2. `Lower_Thirds/Modern_Lower_Thirds.prproj` - Premiere Pro project for graphic overlays.
3. `Assets/YouTube_Safety_Boundaries.png` - Overlay to verify text is inside safe zones.

## How to use:
- **Photoshop**: Open `Clean_Vlog_Thumbnail.psd`, double click the Smart Object layer to insert your main visual, edit the big text, and export as JPG.
- **Premiere Pro**: Import `Modern_Lower_Thirds.prproj` into your project and drag the Essential Graphics templates onto your timeline.
