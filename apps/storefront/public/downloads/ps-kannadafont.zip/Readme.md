# Kannada Typography Kit
Created by Venkatesh Narasimha

A complete typography kit for mixed Kannada-English typesetting in Photoshop, including font pairings, color palettes, and ExtendScript styling presets.

## Contents:
1. `Kannada Type Installer.jsx` - Photoshop script to create styled text templates in one click.
2. `Karnataka Swatches.ase` - Adobe Swatch Exchange color palette file containing heritage colors (Mysore Red, Haldi Yellow, Silk Gold, Western Ghats Green).
3. `Fonts Guide.md` - Compilation of premium free Kannada fonts with direct Google Fonts links.

## Google Fonts Recommendation:
We highly recommend downloading and installing these free fonts before running the installer script:
- **Baloo Tamma 2** (Bold & Rounded Titles) -> https://fonts.google.com/specimen/Baloo+Tamma+2
- **Noto Sans Kannada** (Clean, Modern Body Text) -> https://fonts.google.com/specimen/Noto+Sans+Kannada
- **Rozha One** (Decorative Editorial Titles) -> https://fonts.google.com/specimen/Rozha+One
