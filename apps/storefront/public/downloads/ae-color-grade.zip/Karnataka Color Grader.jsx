/**
 * Karnataka Color Grader v1.0
 * by Venkatesh Narasimha
 */
(function(thisObj) {
    function buildUI(container) {
        var myPanel = (container instanceof Panel) ? container : new Window("palette", "Karnataka Color Grader", undefined, {resizeable: true});
        myPanel.orientation = "column";
        myPanel.alignChildren = ["fill", "top"];
        myPanel.margins = 16;
        
        myPanel.add("statictext", undefined, "Select Karnataka Look:");
        var lutDrop = myPanel.add("dropdownlist", undefined, [
            "Mysuru Golden Hour (Warm Palace Tone)",
            "Coorg Emerald (Lush Forest Green)",
            "Hampi Ochre Ruins (Earthy Historic Contrast)"
        ]);
        lutDrop.selection = 0;
        
        var btnApply = myPanel.add("button", undefined, "Apply Color Grade 🎨");
        btnApply.onClick = function() {
            var comp = app.project.activeItem;
            if (!comp || !(comp instanceof CompItem)) {
                alert("Please select a composition!");
                return;
            }
            app.beginUndoGroup("Apply Karnataka LUT");
            
            // Create Adjustment Layer
            var adjLayer = comp.layers.addSolid([1, 1, 1], "Karnataka Grade - " + lutDrop.selection.text, comp.width, comp.height, comp.pixelAspect, comp.duration);
            adjLayer.adjustmentLayer = true;
            
            // Apply Lumetri Color or Slider
            try {
                var effect = adjLayer.property("Effects").addProperty("Lumetri Color");
                // Note: Loading actual cube files is done via Lumetri's parameters
            } catch(e) {}
            
            app.endUndoGroup();
            alert("Applied grading preset: " + lutDrop.selection.text);
        };
        myPanel.layout.layout(true);
        return myPanel;
    }
    buildUI(thisObj);
})(this);
